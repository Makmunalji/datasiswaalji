
<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    * {
        box-sizing: border-box;
    }

    .detail-page {
        padding: 20px 10px;
        min-height: 65vh;
    }

    .detail-header {
        margin-bottom: 25px;
    }

    .detail-header h1 {
        color: #1e3a8a;
        font-size: 28px;
        margin: 0 0 8px;
    }

    .detail-header p {
        color: #64748b;
        font-size: 14px;
        margin: 0;
    }

    .alert-success {
        background: #dcfce7;
        color: #166534;
        border: 1px solid #bbf7d0;
        padding: 13px 16px;
        border-radius: 9px;
        margin-bottom: 20px;
    }

    .detail-card {
        max-width: 850px;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,.07);
    }

    .detail-card-header {
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
        padding: 25px;
        display: flex;
        align-items: center;
        gap: 18px;
    }

    .student-avatar {
        width: 65px;
        height: 65px;
        border-radius: 50%;
        background: rgba(255,255,255,.2);
        border: 2px solid rgba(255,255,255,.5);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        font-weight: bold;
        color: white;
        flex-shrink: 0;
    }

    .student-heading h2 {
        margin: 0 0 7px;
        font-size: 21px;
        color: white;
    }

    .student-heading p {
        margin: 0;
        font-size: 13px;
        color: #dbeafe;
    }

    .detail-content {
        padding: 25px;
    }

    .detail-title {
        font-size: 17px;
        color: #1e3a8a;
        font-weight: bold;
        margin-bottom: 18px;
    }

    .detail-table {
        width: 100%;
        border-collapse: collapse;
    }

    .detail-table td {
        padding: 15px 12px;
        border-bottom: 1px solid #e2e8f0;
        font-size: 14px;
        color: #334155;
    }

    .detail-table tr:last-child td {
        border-bottom: none;
    }

    .detail-table td:first-child {
        width: 180px;
        color: #64748b;
        font-weight: 600;
    }

    .detail-table td:nth-child(2) {
        width: 20px;
        color: #94a3b8;
    }

    .badge-class {
        display: inline-block;
        background: #dbeafe;
        color: #1e40af;
        padding: 6px 13px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }

    .badge-major {
        display: inline-block;
        background: #eff6ff;
        color: #2563eb;
        padding: 6px 13px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }

    .detail-actions {
        display: flex;
        gap: 10px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
    }

    .btn-back,
    .btn-edit {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 11px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: bold;
        text-decoration: none;
        transition: .3s;
    }

    .btn-back {
        background: #f1f5f9;
        color: #475569;
    }

    .btn-back:hover {
        background: #e2e8f0;
    }

    .btn-edit {
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
    }

    .btn-edit:hover {
        background: #1e40af;
        transform: translateY(-2px);
    }

    @media (max-width: 600px) {
        .detail-header h1 {
            font-size: 23px;
        }

        .detail-content {
            padding: 15px;
        }

        .detail-card-header {
            padding: 20px 15px;
        }

        .student-heading h2 {
            font-size: 17px;
        }

        .detail-table td {
            padding: 12px 5px;
            font-size: 13px;
        }

        .detail-table td:first-child {
            width: 110px;
        }

        .detail-actions {
            flex-direction: column;
        }

        .btn-back,
        .btn-edit {
            width: 100%;
        }
    }
</style>

<div class="detail-page">

    <div class="detail-header">
        <h1>Detail Siswa</h1>
        <p>Informasi lengkap data siswa SMK Miftahul Khoir.</p>
    </div>

    <?php if (!empty($success)): ?>
        <div class="alert-success">
            ✓ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="detail-card">

        <div class="detail-card-header">

            <div class="student-avatar">
                <?= strtoupper(substr($student['name'], 0, 1)) ?>
            </div>

            <div class="student-heading">
                <h2><?= htmlspecialchars($student['name']) ?></h2>
                <p>NIS: <?= htmlspecialchars($student['nis']) ?></p>
            </div>

        </div>

        <div class="detail-content">

            <div class="detail-title">
                Informasi Data Siswa
            </div>

            <table class="detail-table">

                <tr>
                    <td>NIS</td>
                    <td>:</td>
                    <td><?= htmlspecialchars($student['nis']) ?></td>
                </tr>

                <tr>
                    <td>Nama Lengkap</td>
                    <td>:</td>
                    <td>
                        <strong>
                            <?= htmlspecialchars($student['name']) ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>Kelas</td>
                    <td>:</td>
                    <td>
                        <span class="badge-class">
                            <?= htmlspecialchars($student['class_name']) ?>
                        </span>
                    </td>
                </tr>

                <tr>
                    <td>Jurusan</td>
                    <td>:</td>
                    <td>
                        <span class="badge-major">
                            <?= htmlspecialchars($student['major']) ?>
                        </span>
                    </td>
                </tr>

            </table>

            <div class="detail-actions">

                <a href="index.php" class="btn-back">
                    ← Kembali
                </a>

                <a href="edit.php?id=<?= urlencode($student['id']) ?>"
                   class="btn-edit">
                    ✎ Edit Data
                </a>

            </div>

        </div>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
