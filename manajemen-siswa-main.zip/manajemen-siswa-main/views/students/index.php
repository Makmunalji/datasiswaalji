
<?php require 'views/layouts/header.php'; ?>

<style>
    * {
        box-sizing: border-box;
    }

    .page-container {
        padding: 20px 10px;
        min-height: 65vh;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
        margin-bottom: 25px;
    }

    .page-title h1 {
        margin: 0;
        color: #1e3a8a;
        font-size: 28px;
    }

    .page-title p {
        color: #64748b;
        margin: 7px 0 0;
        font-size: 14px;
    }

    .btn-add {
        display: inline-block;
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
        text-decoration: none;
        padding: 12px 20px;
        border-radius: 9px;
        font-weight: bold;
        box-shadow: 0 4px 10px rgba(37, 99, 235, .2);
        transition: .3s;
    }

    .btn-add:hover {
        background: #1e40af;
        transform: translateY(-2px);
    }

    .alert-success {
        background: #dcfce7;
        color: #166534;
        border: 1px solid #bbf7d0;
        padding: 13px 16px;
        border-radius: 9px;
        margin-bottom: 20px;
    }

    .table-card {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, .07);
        border: 1px solid #e2e8f0;
    }

    .table-title {
        color: #1e3a8a;
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 18px;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

    .student-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 750px;
    }

    .student-table thead {
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
    }

    .student-table th {
        padding: 15px 12px;
        text-align: left;
        font-size: 14px;
        white-space: nowrap;
    }

    .student-table td {
        padding: 14px 12px;
        border-bottom: 1px solid #e2e8f0;
        color: #334155;
        font-size: 14px;
    }

    .student-table tbody tr:hover {
        background: #eff6ff;
    }

    .student-table tbody tr:last-child td {
        border-bottom: none;
    }

    .badge-class {
        background: #dbeafe;
        color: #1e40af;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }

    .badge-gender {
        background: #f1f5f9;
        color: #475569;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 12px;
    }

    .action-buttons {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
    }

    .btn-action {
        text-decoration: none;
        padding: 7px 11px;
        border-radius: 6px;
        color: white;
        font-size: 12px;
        font-weight: bold;
        transition: .2s;
    }

    .btn-detail {
        background: #2563eb;
    }

    .btn-edit {
        background: #f59e0b;
    }

    .btn-delete {
        background: #ef4444;
    }

    .btn-action:hover {
        opacity: .85;
        transform: translateY(-1px);
    }

    .empty-data {
        text-align: center;
        padding: 40px 15px !important;
        color: #94a3b8 !important;
    }

    @media (max-width: 600px) {
        .page-header {
            align-items: flex-start;
        }

        .page-title h1 {
            font-size: 23px;
        }

        .btn-add {
            width: 100%;
            text-align: center;
        }

        .table-card {
            padding: 12px;
        }
    }
</style>

<div class="page-container">

    <div class="page-header">
        <div class="page-title">
            <h1>Daftar Siswa</h1>
            <p>Kelola data siswa SMK Miftahul Khoir dengan mudah.</p>
        </div>

        <a href="create.php" class="btn-add">
            + Tambah Siswa
        </a>
    </div>

    <?php if (!empty($success)): ?>
        <div class="alert-success">
            ✓ <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="table-card">

        <div class="table-title">
            Data Seluruh Siswa
        </div>

        <div class="table-responsive">

            <table class="student-table">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Jenis Kelamin</th>
                        <th>Kelas</th>
                        <th>Jurusan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!empty($students)): ?>

                        <?php foreach ($students as $index => $student): ?>

                            <tr>
                                <td><?= $index + 1 ?></td>

                                <td>
                                    <?= htmlspecialchars($student['nis']) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars($student['name']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <span class="badge-gender">
                                        <?= htmlspecialchars($student['gender']) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="badge-class">
                                        <?= htmlspecialchars($student['class_name']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= htmlspecialchars($student['major']) ?>
                                </td>

                                <td>
                                    <div class="action-buttons">

                                        <a href="student.php?id=<?= urlencode($student['id']) ?>"
                                           class="btn-action btn-detail">
                                            Detail
                                        </a>

                                        <a href="edit.php?id=<?= urlencode($student['id']) ?>"
                                           class="btn-action btn-edit">
                                            Edit
                                        </a>

                                        <a href="delete.php?id=<?= urlencode($student['id']) ?>"
                                           class="btn-action btn-delete"
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">
                                            Hapus
                                        </a>

                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="7" class="empty-data">
                                Belum ada data siswa. Silakan klik tombol
                                Tambah Siswa untuk menambahkan data.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>
    </div>

</div>

<?php require 'views/layouts/footer.php'; ?>
