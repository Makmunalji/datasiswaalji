
<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    * {
        box-sizing: border-box;
    }

    .form-page {
        padding: 20px 10px;
        min-height: 65vh;
    }

    .form-header {
        margin-bottom: 25px;
    }

    .form-header h1 {
        color: #1e3a8a;
        font-size: 28px;
        margin: 0 0 8px;
    }

    .form-header p {
        color: #64748b;
        font-size: 14px;
        margin: 0;
    }

    .form-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 25px;
        max-width: 850px;
        box-shadow: 0 4px 15px rgba(0,0,0,.07);
    }

    .form-card-title {
        font-size: 18px;
        font-weight: bold;
        color: #1e3a8a;
        padding-bottom: 15px;
        margin-bottom: 22px;
        border-bottom: 1px solid #e2e8f0;
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .form-group.full-width {
        grid-column: 1 / -1;
    }

    .form-group label {
        color: #334155;
        font-size: 14px;
        font-weight: 600;
    }

    .form-group input[type="text"] {
        width: 100%;
        height: 44px;
        padding: 10px 13px;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        outline: none;
        font-size: 14px;
        color: #334155;
        background: #fff;
        transition: .2s;
    }

    .form-group input[type="text"]:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
    }

    .gender-options {
        display: flex;
        gap: 20px;
        align-items: center;
        min-height: 44px;
    }

    .gender-options label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: normal;
        cursor: pointer;
    }

    .gender-options input {
        accent-color: #2563eb;
        width: 16px;
        height: 16px;
    }

    .form-info {
        background: #eff6ff;
        border: 1px solid #dbeafe;
        color: #1e40af;
        padding: 12px 15px;
        border-radius: 8px;
        font-size: 13px;
        margin-top: 22px;
    }

    .form-actions {
        display: flex;
        gap: 10px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
    }

    .btn-update {
        border: none;
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        transition: .3s;
    }

    .btn-update:hover {
        background: #1e40af;
        transform: translateY(-2px);
    }

    .btn-cancel {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #f1f5f9;
        color: #475569;
        padding: 12px 24px;
        border-radius: 8px;
        text-decoration: none;
        font-size: 14px;
        font-weight: bold;
        transition: .3s;
    }

    .btn-cancel:hover {
        background: #e2e8f0;
    }

    @media (max-width: 600px) {
        .form-grid {
            grid-template-columns: 1fr;
        }

        .form-card {
            padding: 18px;
        }

        .form-header h1 {
            font-size: 23px;
        }

        .form-actions {
            flex-direction: column;
        }

        .btn-update,
        .btn-cancel {
            width: 100%;
        }
    }
</style>

<div class="form-page">

    <div class="form-header">
        <h1>Edit Data Siswa</h1>
        <p>Perbarui informasi data siswa SMK Miftahul Khoir.</p>
    </div>

    <div class="form-card">

        <div class="form-card-title">
            Formulir Edit Data Siswa
        </div>

        <form action="update.php?id=<?= urlencode($student['id']) ?>"
              method="POST">

            <div class="form-grid">

                <div class="form-group">
                    <label for="nis">NIS</label>
                    <input
                        type="text"
                        id="nis"
                        name="nis"
                        value="<?= htmlspecialchars($student['nis']) ?>"
                        placeholder="Masukkan NIS siswa"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="name">Nama Lengkap</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?= htmlspecialchars($student['name']) ?>"
                        placeholder="Masukkan nama lengkap"
                        required
                    >
                </div>

                <div class="form-group full-width">
                    <label>Jenis Kelamin</label>

                    <div class="gender-options">

                        <label>
                            <input
                                type="radio"
                                name="gender"
                                value="L"
                                <?= $student['gender'] === 'L' ? 'checked' : '' ?>
                                required
                            >
                            Laki-laki
                        </label>

                        <label>
                            <input
                                type="radio"
                                name="gender"
                                value="P"
                                <?= $student['gender'] === 'P' ? 'checked' : '' ?>
                            >
                            Perempuan
                        </label>

                    </div>
                </div>

                <div class="form-group">
                    <label for="class_name">Kelas</label>
                    <input
                        type="text"
                        id="class_name"
                        name="class_name"
                        value="<?= htmlspecialchars($student['class_name']) ?>"
                        placeholder="Contoh: XII"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="major">Jurusan</label>
                    <input
                        type="text"
                        id="major"
                        name="major"
                        value="<?= htmlspecialchars($student['major']) ?>"
                        placeholder="Contoh: Teknik Informatika"
                        required
                    >
                </div>

            </div>

            <div class="form-info">
                ℹ️ Periksa kembali perubahan data sebelum menekan tombol Update Data.
            </div>

            <div class="form-actions">

                <button type="submit" class="btn-update">
                    ✓ Update Data
                </button>

                <a href="index.php" class="btn-cancel">
                    ← Kembali
                </a>

            </div>

        </form>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
